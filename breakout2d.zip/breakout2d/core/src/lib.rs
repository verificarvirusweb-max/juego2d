//! breakout2d-core: reglas de combate puras (sin motor, sin red, sin dependencias).
//! La idea: el servidor autoritativo llama a `resolve_hit` por cada impacto.
//! Los numeros son de ejemplo; en el juego real salen de archivos de datos (RON/JSON).

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Zone { Head, Thorax, Stomach, Arm, Leg }

impl Zone {
    pub const ALL: [Zone; 5] = [Zone::Head, Zone::Thorax, Zone::Stomach, Zone::Arm, Zone::Leg];
    fn idx(self) -> usize { self as usize }
    pub fn multiplier(self) -> f32 {
        match self {
            Zone::Head => 2.0, Zone::Thorax => 1.0, Zone::Stomach => 1.1,
            Zone::Arm => 0.7, Zone::Leg => 0.6,
        }
    }
}

#[derive(Clone, Debug)]
pub struct Ammo {
    pub name: &'static str,
    pub damage: f32,       // dano base
    pub penetration: f32,  // poder de penetracion (clase N de armadura ~ N*10)
    pub armor_damage: f32, // durabilidad que quita a la armadura
}

#[derive(Clone, Debug)]
pub struct Armor {
    pub class: u8,               // tier 1..=6
    pub max_durability: f32,
    pub durability: f32,
    pub blunt_throughput: f32,   // fraccion de dano que pasa si NO penetra (0..1)
    pub covers: Vec<Zone>,
}

impl Armor {
    pub fn new(class: u8, max_durability: f32, blunt: f32, covers: Vec<Zone>) -> Self {
        Self { class, max_durability, durability: max_durability, blunt_throughput: blunt, covers }
    }
    /// Una armadura gastada protege menos: resistencia efectiva baja con la durabilidad.
    pub fn resistance(&self) -> f32 {
        let ratio = (self.durability / self.max_durability).clamp(0.0, 1.0);
        self.class as f32 * 10.0 * (0.4 + 0.6 * ratio)
    }
}

#[derive(Debug, PartialEq)]
pub struct HitResult {
    pub body_damage: f32,
    pub penetrated: bool,
    pub armor_damage: f32,
}

pub fn pen_chance(pen: f32, resistance: f32) -> f32 {
    ((pen - resistance) / 15.0 + 0.5).clamp(0.0, 1.0)
}

/// `roll` en [0,1). Se pasa desde fuera para que sea determinista y testeable.
pub fn resolve_hit(ammo: &Ammo, zone: Zone, armor: Option<&mut Armor>, roll: f32) -> HitResult {
    let base = ammo.damage * zone.multiplier();
    let Some(a) = armor else {
        return HitResult { body_damage: base, penetrated: true, armor_damage: 0.0 };
    };
    if !a.covers.contains(&zone) || a.durability <= 0.0 {
        return HitResult { body_damage: base, penetrated: true, armor_damage: 0.0 };
    }
    let chance = pen_chance(ammo.penetration, a.resistance());
    let penetrated = roll < chance;
    let (body, loss) = if penetrated {
        // penetrar frena un poco la bala: mas cerca del limite, mas dano absorbido
        (base * (1.0 - 0.25 * (1.0 - chance)), ammo.armor_damage * 0.5)
    } else {
        (base * a.blunt_throughput, ammo.armor_damage)
    };
    a.durability = (a.durability - loss).max(0.0);
    HitResult { body_damage: body, penetrated, armor_damage: loss }
}

#[derive(Clone, Debug)]
pub struct Body { hp: [f32; 5], max: [f32; 5] }

impl Body {
    pub fn new() -> Self {
        let max = [35.0, 85.0, 70.0, 60.0, 65.0];
        Self { hp: max, max }
    }
    pub fn hit(&mut self, zone: Zone, dmg: f32) { let i = zone.idx(); self.hp[i] = (self.hp[i] - dmg).max(0.0); }
    pub fn heal(&mut self, zone: Zone, amount: f32) { let i = zone.idx(); self.hp[i] = (self.hp[i] + amount).min(self.max[i]); }
    pub fn hp(&self, zone: Zone) -> f32 { self.hp[zone.idx()] }
    pub fn is_dead(&self) -> bool { self.hp[Zone::Head.idx()] <= 0.0 || self.hp[Zone::Thorax.idx()] <= 0.0 }
}

impl Default for Body { fn default() -> Self { Self::new() } }

#[cfg(test)]
mod tests {
    use super::*;
    const FMJ: Ammo = Ammo { name: "FMJ", damage: 40.0, penetration: 20.0, armor_damage: 8.0 };
    const AP: Ammo = Ammo { name: "AP", damage: 55.0, penetration: 55.0, armor_damage: 14.0 };
    fn vest(class: u8) -> Armor { Armor::new(class, 60.0, 0.3, vec![Zone::Thorax, Zone::Stomach]) }

    #[test]
    fn no_armor_full_damage() {
        let r = resolve_hit(&FMJ, Zone::Thorax, None, 0.5);
        assert_eq!(r.body_damage, 40.0);
    }
    #[test]
    fn weak_ammo_blocked_by_class5() {
        let mut a = vest(5);
        let r = resolve_hit(&FMJ, Zone::Thorax, Some(&mut a), 0.0);
        assert!(!r.penetrated);
        assert!((r.body_damage - 12.0).abs() < 1e-3);
        assert!(a.durability < 60.0);
    }
    #[test]
    fn ap_penetrates_class3() {
        let mut a = vest(3);
        assert!(resolve_hit(&AP, Zone::Thorax, Some(&mut a), 0.99).penetrated);
    }
    #[test]
    fn worn_armor_protects_less() {
        let mut a = vest(4);
        let full = a.resistance();
        a.durability = 10.0;
        assert!(a.resistance() < full);
    }
    #[test]
    fn uncovered_zone_ignores_armor() {
        let mut a = vest(6);
        let r = resolve_hit(&FMJ, Zone::Leg, Some(&mut a), 0.0);
        assert!(r.penetrated);
        assert_eq!(a.durability, 60.0);
    }
    #[test]
    fn head_or_thorax_zero_kills() {
        let mut b = Body::new();
        b.hit(Zone::Head, 100.0);
        assert!(b.is_dead());
    }
}
