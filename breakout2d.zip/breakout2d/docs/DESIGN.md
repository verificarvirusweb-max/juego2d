# Breakout2D: diseño y hoja de ruta

## Principio
Copia las MECANICAS (no son protegibles), no los assets, nombres, armas con licencia, mapas ni
marcas de Arena Breakout. Usa arte, sonido y nombres propios o de licencias libres (CC0).

## Stack recomendado
- Servidor: Rust, autoritativo, tick 30 Hz, QUIC (`quinn`) o WebSocket. Sin confiar en el cliente.
- Cliente: Godot 4 (2D, exporta a Android y PC) o Bevy si quieres todo en Rust.
  El A23 corre un 2D bien optimizado sin problema: tu problema original desaparece.
- Datos: PostgreSQL (cuentas, inventarios, mercado). Reglas de balas/armas/armaduras en RON/JSON.
- Core de reglas: `core/` (este crate), compartido por servidor y tests.

## Sistemas (mapeo a tu lista)
| Sistema | Enfoque |
|---|---|
| Penetracion/armaduras | `core`: clase 1-6, durabilidad, chance de pen, dano contundente |
| Balas 2D | raycast por tick; materiales de pared con espesor que consumen penetracion |
| Curacion | zonas del cuerpo, sangrado, fracturas, items con tiempo de uso |
| Granadas | proyectil + fusible + dano por distancia y linea de vista |
| Mejora de armas | accesorios con modificadores (retroceso, ergonomia, rango) |
| Extraccion | zonas con temporizador; el inventario solo se guarda al extraer |
| Mercado abierto | listados con deposito en escrow, comision, transacciones atomicas en SQL |
| Bots | IA de utilidad/behavior tree con las MISMAS reglas; dificultad = reaccion, error de punteria, equipo |
| Anti-trampas | servidor decide todo; no enviar al cliente lo que no ve (visibilidad/fog of war) |

## Fases (cada una jugable)
1. Core de combate + tests (hecho como base). Sandbox local: 1 jugador vs 1 bot, mapa pequeno.
2. Movimiento, disparo, raycast, armaduras y salud en un mapa 2D. Un solo jugador.
3. Servidor autoritativo + 2 clientes. Prediccion de cliente y reconciliacion.
4. Loop de raid: spawn, loot, extraccion, persistencia de inventario.
5. Bots con equipo variable y comportamiento de patrulla/combate.
6. Economia: tienda NPC, luego mercado entre jugadores (escrow, comision, anti-duplicacion).
7. Balance, telemetria, pruebas de red con latencia simulada (Starlink tiene jitter: pruebalo).

## Riesgos honestos
- Es un proyecto de meses/anos. El mercado entre jugadores y el anti-trampas son lo mas dificil.
- La economia necesita sumideros (comisiones, reparaciones) o se rompe por inflacion.
- Un mercado real con dinero real trae temas legales/fiscales: empieza con moneda virtual sin cashout.
- Empieza con 2-4 jugadores por raid, no 60.
