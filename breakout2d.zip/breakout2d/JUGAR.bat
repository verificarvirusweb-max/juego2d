@echo off
setlocal
cd /d "%~dp0"
title Breakout2D - instalar y jugar
echo ============================================
echo   Breakout2D MVP - instalador y lanzador
echo ============================================
echo.

set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"

rem ---- 1) Visual Studio Build Tools (linker C++) ----
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "HASVS="
if not exist "%VSWHERE%" goto installvs
for /f "usebackq delims=" %%i in (`"%VSWHERE%" -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "HASVS=%%i"
if not defined HASVS goto installvs
goto checkrust

:installvs
echo [1/3] Instalando Visual Studio Build Tools con C++ ^(pesa varios GB, puede tardar^)...
echo       Si Windows pide permiso de administrador, acepta.
where winget >nul 2>nul
if errorlevel 1 goto novswinget
winget install --id Microsoft.VisualStudio.2022.BuildTools -e --accept-package-agreements --accept-source-agreements --override "--passive --wait --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
goto checkrust

:novswinget
echo No se encontro winget en este Windows.
echo Instala manualmente "Build Tools for Visual Studio" con la carga "Desarrollo para escritorio con C++".
start https://visualstudio.microsoft.com/visual-cpp-build-tools/
pause
exit /b 1

rem ---- 2) Rust ----
:checkrust
where cargo >nul 2>nul
if not errorlevel 1 goto build
echo.
echo [2/3] Instalando Rust...
powershell -NoProfile -Command "Invoke-WebRequest https://win.rustup.rs/x86_64 -OutFile rustup-init.exe"
if not exist rustup-init.exe goto fail
rustup-init.exe -y --default-host x86_64-pc-windows-msvc --default-toolchain stable
del rustup-init.exe
set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"
where cargo >nul 2>nul
if errorlevel 1 goto fail

rem ---- 3) Compilar ----
:build
echo.
echo Asegurando toolchain MSVC de Rust...
rustup toolchain install stable-x86_64-pc-windows-msvc
rustup default stable-x86_64-pc-windows-msvc
if errorlevel 1 goto fail
echo.
echo [3/3] Compilando el juego ^(la primera vez tarda varios minutos, necesita internet^)...
cargo build --release -p breakout2d
if errorlevel 1 goto fail
if not exist play mkdir play
copy /y target\release\breakout2d.exe play\ >nul
echo Listo: play\breakout2d.exe

rem ---- Menu ----
:menu
echo.
echo   1) Jugar contra bots ^(HOST^)
echo   2) Unirme a un host ^(o abrir 2da ventana local^)
echo   3) Salir
choice /c 123 /n /m "Elige una opcion: "
if errorlevel 3 exit /b 0
if errorlevel 2 goto join
start "" "play\breakout2d.exe" host
goto menu

:join
set "IP="
set /p IP=IP del host ^(Enter = 127.0.0.1^): 
if not defined IP set "IP=127.0.0.1"
start "" "play\breakout2d.exe" join %IP%
goto menu

:fail
echo.
echo Algo fallo. Copia el mensaje de error de arriba y mandamelo.
echo Si acabas de instalar Visual Studio Build Tools, reinicia Windows y vuelve a abrir este archivo.
pause
exit /b 1
